//
//  AppDelegate.m
//  DictionaryTest (Lesson 8)
//
//  Created by Anton Gorlov on 05.10.15.
//  Copyright © 2015 Anton Gorlov. All rights reserved.
//

#import "AppDelegate.h"

@interface AppDelegate ()

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    // Override point for customization after application launch.
    
    //1-й способ создания библиотеки.
    NSDictionary* cars=[[NSDictionary alloc]initWithObjectsAndKeys:
                        @"Sedan",@"Toyota",
                        @"HatchBack",@"Mazda",
                        @"TheBucket",@"ZAZ",
                        @"SportCar",@"Ferrari",
                        [NSNumber numberWithInt:10],@"age of a car",
                        nil];//в этом способе сначало-обьект,потом - ключ.
    
    NSLog(@"%@ \ncount=%ld",cars,[cars count]);//cars распечатывает.
    
    // как брать обьекты.
    NSLog(@"type=%@,type=%@,type=%@,type=%@ ,age=%ld",//чтобы получить доступ к какому-то элементу cars нам надо обратиться по его ключу.
          [cars objectForKey:@"Toyota"],
          [cars objectForKey:@"Mazda"],
          [cars objectForKey:@"ZAZ"],
          [cars objectForKey:@"Ferrari"],
          [[cars objectForKey:@"age of a car"]integerValue]);
  
    //[[cars objectForKey:@"age of a car"]integerValue])- прога думает,что это обьект,не знает что это NSNumber.
    
    
    //2-й способ создания библиотеки.
    NSDictionary* dictionary=[NSDictionary dictionaryWithObjectsAndKeys:@"animal",@"camel",@"animal2",@"frog", nil];
    NSLog(@"%@ and count=%ld",dictionary,[dictionary count]);
    
     //3-й способ создания библиотеки.
    NSDictionary*dictionary2=@{@"name":@"Ivan",@"lastName":@"Kurva",@"age":[NSNumber numberWithInt:25]}; //вместо [NSNumber numberWithInt:25] можно @25.
    NSLog(@"%@ and count=%ld",dictionary2,[dictionary2 count]);
    
/* 
     NSInteger number=25; если целое число,то нужно записать - "@(number)"
     NSDictionary* dictionary2=@{@"name":@"Ivan",@"lastName":@"Kurva",@"age":@(number)};
 
 */
    
    for (NSString*key in [cars allKeys]) { //обьект класса "NSString", наз переменной "key",вывод всех ключей в массиве(если не знаем массив,то необходимо узнать ключи).
        id obj=[cars objectForKey:key];//по каждому ключу можно доставать его значение.
        NSLog(@"key=%@, value=%@",key,obj);
    
    
    }
    
    


    
    
    
    
    
    
    
    return YES;
}

- (void)applicationWillResignActive:(UIApplication *)application {
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application {
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}

- (void)applicationWillEnterForeground:(UIApplication *)application {
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)applicationDidBecomeActive:(UIApplication *)application {
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}

- (void)applicationWillTerminate:(UIApplication *)application {
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

@end
