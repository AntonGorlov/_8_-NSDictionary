//
//  AGStudent.m
//  HomeWork Lesson 8 (Dictionary)
//
//  Created by Anton Gorlov on 06.10.15.
//  Copyright © 2015 Anton Gorlov. All rights reserved.
//

#import "AGStudent.h"

@implementation AGStudent

-(NSString*) description {
    NSString*string= [NSString stringWithFormat:@"%@ %@, %@",self.name,self.lastName,self.wellcomeSpeach];
    return string;
}





@end
