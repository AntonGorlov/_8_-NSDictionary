//
//  AGStudent.h
//  HomeWork Lesson 8 (Dictionary)
//
//  Created by Anton Gorlov on 06.10.15.
//  Copyright © 2015 Anton Gorlov. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface AGStudent : NSObject
@property (strong, nonatomic) NSString* name;
@property (assign,nonatomic) NSString* lastName;
@property (assign,nonatomic) NSString* wellcomeSpeach;


@end
