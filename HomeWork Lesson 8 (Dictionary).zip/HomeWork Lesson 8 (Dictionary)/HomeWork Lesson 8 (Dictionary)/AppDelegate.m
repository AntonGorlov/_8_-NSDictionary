//
//  AppDelegate.m
//  HomeWork Lesson 8 (Dictionary)
//
//  Created by Anton Gorlov on 06.10.15.
//  Copyright © 2015 Anton Gorlov. All rights reserved.
//

#import "AppDelegate.h"
#import "AGStudent.h"
@interface AppDelegate ()

@end

@implementation AppDelegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    // Override point for customization after application launch.
  
    
    /*
     Уровень Ученик
     
     1. Создайте класс студент со свойствами имя, фамилия и фраза приветствия.
     2. Создайте 10 - 15 объектов этого класса.
     3. Теперь мы создадим дикшинари типо школьный журнал, где ключ будет фамилия + имя, а значение сам студент.
     4. Распечатайте дикшинари
     */

    AGStudent*student=[[AGStudent alloc]init];
    AGStudent*student1=[[AGStudent alloc]init];
    AGStudent*student2=[[AGStudent alloc]init];
    AGStudent*student3=[[AGStudent alloc]init];
    AGStudent*student4=[[AGStudent alloc]init];
    AGStudent*student5=[[AGStudent alloc]init];
    AGStudent*student6=[[AGStudent alloc]init];
    AGStudent*student7=[[AGStudent alloc]init];
    AGStudent*student8=[[AGStudent alloc]init];
    AGStudent*student9=[[AGStudent alloc]init];
    AGStudent*student10=[[AGStudent alloc]init];
    AGStudent*student11=[[AGStudent alloc]init];
   

    
    
    student.name=@"Oksana";
    student.lastName=@"Paraka";
    student.wellcomeSpeach=@"Hello";
    
    student.name=@"Vika";
    student.lastName=@"Smotrikova";
    student1.wellcomeSpeach=@"My name is Vika";
    
    student.name=@"Viktoria";
    student.lastName=@"Kormilec";
    student2.wellcomeSpeach=@"Hey";
    
    student.name=@"Anna";
    student.lastName=@"Susina";
    student3.wellcomeSpeach=@"Hi";
    
    student.name=@"Nastja";
    student.lastName=@"Trigubenko";
    student4.wellcomeSpeach=@"What's up?";
    
    student.name=@"Tanja";
    student.lastName=@"Mrchenko";
    student5.wellcomeSpeach=@"What's news with you?";
    
    student.name=@"Karina";
    student.lastName=@"Simhuck";
    student6.wellcomeSpeach=@"How are you?";
    
    student.name=@"Marina";
    student.lastName=@"Dovgal";
    student7.wellcomeSpeach=@"Hey hay";
    
    student.name=@"Kristina";
    student.lastName=@"Hodeeva";
    student8.wellcomeSpeach=@"Privet";
    
    student.name=@"Ula";
    student.lastName=@"Berezkina";
    student9.wellcomeSpeach=@"Zdarova";
    
    student.name=@"Sveta";
    student.lastName=@"Kulinich";
    student10.wellcomeSpeach=@"How is it going?";
    
    student.name=@"Alina";
    student.lastName=@"Plugina";
    student11.wellcomeSpeach=@"How are you doing?";
    
    
    //в  этом дикшинари сначала обьект,потом ключ.
    
    NSDictionary*schoolDictionary=@{@"Oksana Paraka":@"student",
                                    @"Vika Smotrikova":@"student1",
                                    @"Viktoria Kormilec":@"student2",
                                    @"Anna Susina":@"student3",
                                    @"Nastja Trigubenko":@"student4",
                                    @"Tanja Mrchenko":@"student5",
                                    @"Karina Simhuck":@"student6",
                                    @"Marina Dovgal":@"student7",
                                    @"Kristina Hodeeva":@"student8",
                                    };
    NSLog(@"%@",schoolDictionary);
    
    
    NSDictionary*sheSays=@{
                                    @"Oksana Paraka":@"She says: Hi",
                                    @"Vika Smotrikova":@"She says: Hey",
                                    @"Viktoria Kormilec":@"She says: Hello",
                                    @"Anna Susina":@"She says: What's up?",
                                    @"Nastja Trigubenko":@"She says: What's news with you?",
                                    @"Tanja Mrchenko":@"She says: How are you",
                                    @"Karina Simhuck":@"She says: How is it going?",
                                    @"Marina Dovgal":@"How are you doing?",
                                    @"Kristina Hodeeva":@"Hey hay",
                                    };
   

/*
    NSDictionary*schoolDictionary=[[NSDictionary alloc]initWithObjectsAndKeys:
                                   
                                   @"student",@"Oksana Paraka",
                                   @"student1",@"Vika Smotrikova",
                                   @"student2",@"Viktoria Kormilec",
                                   @"student3",@"Anna Susina",
                                   @"student4",@"Nastja Trigubenko",
                                   @"student5",@"Tanja Mrchenko",
                                   @"student6",@"Karina Simhuck",
                                   @"student7",@"Marina Dovgal",
                                   @"student8",@"Kristina Hodeeva",
                                   @"student9",@"Ula Berezkina",
                                   @"student10",@"Sveta Kulinich",
                                   @"student11",@"Alina Plugina",
                                   nil];
    NSLog(@"%@, \n count students=%ld",schoolDictionary, [schoolDictionary count]);
 */
    
/*   Уровень Студент.
    
    5. В цикле пройдемся по всем ключам в дикшинари и распечатаем имя и фамилию каждого студента + его фразу приветствия.
*/
  //For : наши ключи-это строка в дикшинари показать все имеющиеся ключи и АЙдИ.По каждому ключу достаем значение.Распечатываем ключи и обьекты(значения) с одного и др. дикшинари.
    
    for (NSString*keys in [schoolDictionary allKeys]){
    id obj =[schoolDictionary objectForKey:keys];//обращение по его ключу.
        NSLog(@"keys=%@, obj=%@,%@",keys,obj,[sheSays objectForKey:keys]);
        
    }
    //выведем количество студентов в дикшанари
    NSLog(@"count students = %ld",[sheSays count]);
    
/*
                                       Уровень Мастер.
    
    6. Чтобы сделать тоже самое но по какому-то порядку, отсортируйте массив ключей по возрастанию и выведите приветствие каждого студента из дикшинари, но уже по отсортированному списку.
    
    Супермена тут больше нет :)
*/
/*
    NSMutableDictionary*magazine=[[NSMutableDictionary alloc]init];
    NSMutableArray*arrayKeys=[NSMutableArray array];
    NSArray*arrayStudent=[arrayKeys sortedArrayUsingSelector:@selector(compare:)];
    for ( NSArray*keySort in arrayStudent){
        id studentSort=[schoolDictionary objectForKey:keySort];
        NSLog(@"Student %@ she says is %@",keySort,[sheSays objectForKey:keySort]);
    }
    
 */
    NSLog(@"--------------------------MASTER------------------------------");
    
    NSInteger a=0;
    
    //соз массив со всеми ключами и отсортируем его.
    //соз цикл в массиве со строками на ключи и распечатаем ту лабуду.Счет студентов от "0" и увеличиваем +1.
    NSArray*sortedKey=[[sheSays allKeys]sortedArrayUsingSelector:@selector(compare:)];
    for (NSString*keySort in sortedKey){
        AGStudent*man=[sheSays objectForKey:keySort];
        NSLog(@"Student  %ld ,%@ \n",a,man);
        a++;
    }
    
    
    return YES;
}

- (void)applicationWillResignActive:(UIApplication *)application {
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application {
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}

- (void)applicationWillEnterForeground:(UIApplication *)application {
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)applicationDidBecomeActive:(UIApplication *)application {
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}

- (void)applicationWillTerminate:(UIApplication *)application {
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

@end
